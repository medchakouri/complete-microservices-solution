package com.example.coursservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

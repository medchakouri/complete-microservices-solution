package com.example.etudiantservice;
import com.example.etudiantservice.entities.Etudiant;
import com.example.etudiantservice.repository.EtudiantRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;

@SpringBootApplication
public class EtudiantServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtudiantServiceApplication.class, args);
	}

	@Bean
	CommandLineRunner start(EtudiantRepository etudiantRepository, RepositoryRestConfiguration restConfiguration){
		restConfiguration.exposeIdsFor(Etudiant.class);
		return args -> {
			etudiantRepository.save(new Etudiant(null, "Mohamed", 18));
			etudiantRepository.save(new Etudiant(null, "Achraf", 14));
			etudiantRepository.save(new Etudiant(null, "Yassine", 15));
			etudiantRepository.findAll().forEach(etudiant -> {
				System.out.println(etudiant.toString());
			});
		};
	}
}
